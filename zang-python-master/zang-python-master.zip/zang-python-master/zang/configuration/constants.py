BASE_URL = 'http://api.zang.io'
API_VERSION = 'v2'
