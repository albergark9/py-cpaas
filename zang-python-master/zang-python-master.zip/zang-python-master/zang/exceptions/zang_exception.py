# -*- coding: utf-8 -*-

"""
zang.exceptions
~~~~~~~~~~~~~~~~~~~
This module contains the set of Requests' exceptions.
"""


class ZangException(Exception):
    pass
