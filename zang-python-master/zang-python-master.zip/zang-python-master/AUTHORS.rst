Author/Maintainer
=================

- Matija Bogdanovic <matija.bogdanovic@gmail.com> `@matijabogdanovic <https://github.com/matijabogdanovic>`_